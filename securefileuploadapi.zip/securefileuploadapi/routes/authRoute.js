const express = require('express');
const router = express.Router();
const jwt = require('jsonwebtoken');

// Dummy user for login
const dummyUser = {
  username: 'admin',
  password: 'password'  // Simple for testing
};

// Login route
router.post('/login', (req, res) => {
  const { username, password } = req.body;
  if (username === dummyUser.username && password === dummyUser.password) {
    const token = jwt.sign({ username }, 'your_jwt_secret', { expiresIn: '1h' });
    res.json({ token });
  } else {
    res.status(401).json({ message: 'Invalid credentials' });
  }
});

module.exports = router;
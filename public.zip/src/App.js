import React, { useState, useEffect, useRef } from "react";
import "./App.css";

function App() {
  const [output, setOutput] = useState("Say something...");
  const [listening, setListening] = useState(false);
  const recognitionRef = useRef(null);

  useEffect(() => {
    const SpeechRecognition =
      window.SpeechRecognition || window.webkitSpeechRecognition;

    if (!SpeechRecognition) {
      alert("Your browser does not support Speech Recognition. Please use Chrome!");
      return;
    }

    const recognition = new SpeechRecognition();
    recognition.continuous = true;
    recognition.lang = "en-US";
    recognitionRef.current = recognition;

    recognition.onstart = () => {
      setListening(true);
      setOutput("Listening...");
    };

    recognition.onresult = (event) => {
      const transcript =
        event.results[event.results.length - 1][0].transcript.trim().toLowerCase();
      console.log("Heard:", transcript);

      if (transcript.includes("open google")) {
        window.open("https://www.google.com", "_blank");
        setOutput("Opening Google...");
      } else if (transcript.includes("change color")) {
        document.body.style.background = getRandomGradient();
        setOutput("Background color changed!");
      } else if (transcript.includes("show time")) {
        setOutput(`Current Time: ${new Date().toLocaleTimeString()}`);
      } else {
        setOutput(`Heard: "${transcript}"`);
      }
    };

    recognition.onerror = (e) => {
      setListening(false);
      setOutput(`Mic error: ${e.error}`);
    };

    recognition.onend = () => {
      setListening(false);
      setOutput("Stopped Listening. Click Start again.");
    };
  }, []);

  const startListening = () => {
    try {
      recognitionRef.current.start();
    } catch (error) {
      console.error("Error starting recognition:", error);
    }
  };

  const getRandomGradient = () => {
    const colors = [
      ["#ff9a9e", "#fad0c4"],
      ["#a18cd1", "#fbc2eb"],
      ["#fbc2eb", "#a6c1ee"],
      ["#fda085", "#f6d365"],
      ["#96fbc4", "#f9f586"],
    ];
    const random = colors[Math.floor(Math.random() * colors.length)];
    return `linear-gradient(135deg, ${random[0]}, ${random[1]})`;
  };

  return (
    <div className="App">
      <h1>Voice Dashboard Devanshi 🔥</h1>
      <p className="note">
        Say <strong>"open Google"</strong>, <strong>"change color"</strong>, or{" "}
        <strong>"show time"</strong>
      </p>
      <button onClick={startListening} disabled={listening}>
        {listening ? "Listening..." : "Start Listening 🎙️"}
      </button>
      <p>{output}</p>
    </div>
  );
}

export default App;
